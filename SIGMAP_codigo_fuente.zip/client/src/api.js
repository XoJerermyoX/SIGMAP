const BASE="http://localhost:3001/api";
export async function api(path,options={}){
  const token=localStorage.getItem("token");
  const r=await fetch(BASE+path,{...options,headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{}) ,...(options.headers||{})}});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||"Error en la solicitud");
  return data;
}