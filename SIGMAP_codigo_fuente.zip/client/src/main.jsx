import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import {api} from "./api";
import "./styles.css";

const badge=x=><span className={"badge "+String(x).replaceAll(" ","-")}>{x}</span>;
const fmt=n=>`${Math.floor(n/60)}h ${n%60}m`;

function Login({onLogin}){
 const [email,setEmail]=useState("gerencia@sigmap.do"),[password,setPassword]=useState("123456"),[err,setErr]=useState("");
 async function submit(e){e.preventDefault();try{const r=await api("/auth/login",{method:"POST",body:JSON.stringify({email,password})});localStorage.setItem("token",r.token);localStorage.setItem("user",JSON.stringify(r.user));onLogin(r.user)}catch(e){setErr(e.message)}}
 return <div className="login-bg"><form className="login-card" onSubmit={submit}><h1>SIGMAP</h1><p>Sistema de Gestión de Mantenimiento<br/>Industrial</p><label>Correo electrónico</label><input value={email} onChange={e=>setEmail(e.target.value)}/><label>Contraseña</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)}/>{err&&<div className="error">{err}</div>}<button>Iniciar sesión</button><div className="demo"><b>Usuario de prueba (Gerencia)</b><br/>gerencia@sigmap.do — 123456</div></form></div>
}

function Layout({user,page,setPage,children,onLogout}){
 return <div className="app"><aside><div className="brand">SIGMAP<small>Mantenimiento Industrial</small></div>{["Panel de control","Órdenes","Máquinas","Reportes"].map(x=><button key={x} className={page===x?"active":""} onClick={()=>setPage(x)}>{x}</button>)}</aside><main><header><div><b>{user.nombre}</b><small>{user.rol}</small></div><button className="link" onClick={onLogout}>Cerrar sesión</button></header>{children}</main></div>
}
function Cards({items}){return <div className="cards">{items.map(([v,l])=><div className="card" key={l}><strong>{v}</strong><span>{l}</span></div>)}</div>}

function Dashboard(){
 const [orders,setOrders]=useState([]),[notes,setNotes]=useState([]),[rep,setRep]=useState(null),[machines,setMachines]=useState([]);
 useEffect(()=>{Promise.all([api("/ordenes"),api("/notificaciones"),api("/reportes/resumen"),api("/maquinas")]).then(([o,n,r,m])=>{setOrders(o);setNotes(n);setRep(r);setMachines(m)})},[]);
 if(!rep)return <p>Cargando...</p>;
 return <section><h2>Panel de control</h2><p className="muted">Resumen general del mantenimiento.</p><Cards items={[[orders.filter(o=>o.estado!=="cerrada").length,"ÓRDENES ABIERTAS"],[orders.length,"ÓRDENES TOTALES"],[fmt(rep.downtime),"TIEMPO DE PARADA ACUMULADO"],[machines.filter(m=>m.estado==="detenida").length,"MÁQUINAS DETENIDAS"]]}/><div className="panel"><h3>Órdenes pendientes</h3><TableOrders orders={orders.filter(o=>o.estado!=="cerrada").slice(0,4)}/></div><div className="panel"><h3>Notificaciones</h3>{notes.map(n=><div className="note" key={n.id}>{n.mensaje}<span>Marcar leído</span></div>)}</div></section>
}
function TableOrders({orders,onView}){
 return <div className="table-wrap"><table><thead><tr><th>FOLIO</th><th>MÁQUINA</th><th>TIPO</th><th>PRIORIDAD</th><th>ESTADO</th><th>TÉCNICO</th><th>CAUSA RAÍZ</th>{onView&&<th/>}</tr></thead><tbody>{orders.map(o=><tr key={o.id}><td><b>{o.folio}</b></td><td>{o.maquina}</td><td>{badge(o.tipo)}</td><td>{badge(o.prioridad)}</td><td>{badge(o.estado)}</td><td>{o.tecnico||"—"}</td><td>{o.causa_raiz?"Sí":"—"}</td>{onView&&<td><button className="link" onClick={()=>onView(o.id)}>Ver</button></td>}</tr>)}</tbody></table></div>
}
function Orders(){
 const [orders,setOrders]=useState([]),[estado,setEstado]=useState(""),[tipo,setTipo]=useState(""),[detail,setDetail]=useState(null);
 const load=()=>api(`/ordenes?${estado?`estado=${estado}&`:""}${tipo?`tipo=${tipo}`:""}`).then(setOrders);
 useEffect(load,[estado,tipo]);
 if(detail)return <OrderDetail id={detail} back={()=>setDetail(null)}/>;
 return <section><h2>Órdenes de mantenimiento</h2><p className="muted">Registro y seguimiento de trabajos preventivos y correctivos.</p><button className="primary" onClick={()=>alert("Formulario de alta: seleccione máquina, tipo, prioridad y descripción.")}>+ Reportar falla / crear orden</button><div className="filters"><label>Filtrar por estado<select value={estado} onChange={e=>setEstado(e.target.value)}><option value="">Todo</option><option>abierta</option><option>asignada</option><option>en proceso</option><option>cerrada</option></select></label><label>Filtrar por tipo<select value={tipo} onChange={e=>setTipo(e.target.value)}><option value="">Todo</option><option>correctiva</option><option>preventiva</option></select></label></div><div className="panel"><TableOrders orders={orders} onView={setDetail}/></div></section>
}
function OrderDetail({id,back}){
 const [d,setD]=useState(null); useEffect(()=>{api(`/ordenes/${id}`).then(setD)},[id]); if(!d)return <p>Cargando...</p>;
 const o=d.orden,c=d.causa;
 return <section><button className="link" onClick={back}>← Volver a órdenes</button><h2>Orden {o.folio}</h2><p className="muted">{o.maquina} — {o.maquina_nombre}</p><div className="panel"><h3>Información general</h3><div className="info-grid"><div><small>TIPO</small>{badge(o.tipo)}</div><div><small>PRIORIDAD</small>{badge(o.prioridad)}</div><div><small>ESTADO</small>{badge(o.estado)}</div><div><small>REPORTADO POR</small><b>{o.reportado_nombre}</b></div><div><small>TÉCNICO</small><b>{o.tecnico||"Sin asignar"}</b></div><div><small>DESCRIPCIÓN</small><b>{o.descripcion}</b></div></div></div><div className="panel"><h3>Análisis de causa raíz (5 porqués)</h3>{c?<><ol>{[c.porque_1,c.porque_2,c.porque_3,c.porque_4,c.porque_5].filter(Boolean).map((x,i)=><li key={i}>{x}</li>)}</ol><p><b>Causa identificada:</b> {c.causa_identificada}</p><p><b>Acción correctiva:</b> {c.accion_correctiva}</p></>:<p className="muted">No se ha registrado análisis de causa raíz.</p>}</div></section>
}
function Machines(){
 const [machines,setMachines]=useState([]),[hist,setHist]=useState(null); useEffect(()=>{api("/maquinas").then(setMachines)},[]);
 if(hist)return <MachineHistory id={hist} back={()=>setHist(null)}/>;
 return <section><h2>Máquinas</h2><p className="muted">Equipos registrados en la planta y su estado actual.</p><button className="primary">+ Registrar máquina</button><div className="panel table-wrap"><table><thead><tr><th>CÓDIGO</th><th>NOMBRE</th><th>TIPO</th><th>ÁREA</th><th>ESTADO</th><th>ÓRDENES ABIERTAS</th><th/></tr></thead><tbody>{machines.map(m=><tr key={m.id}><td><b>{m.codigo}</b></td><td>{m.nombre}</td><td>{m.tipo}</td><td>{m.area}</td><td>{badge(m.estado)}</td><td>{m.ordenes_abiertas}</td><td><button className="link" onClick={()=>setHist(m.id)}>Historial</button></td></tr>)}</tbody></table></div></section>
}
function MachineHistory({id,back}){
 const [d,setD]=useState(null);useEffect(()=>{api(`/maquinas/${id}/historial`).then(setD)},[id]);if(!d)return <p>Cargando...</p>;
 return <section><button className="link" onClick={back}>← Volver a máquinas</button><h2>{d.maquina.codigo} — {d.maquina.nombre}</h2><p className="muted">Historial de mantenimiento</p><Cards items={[[d.stats.total,"ÓRDENES REGISTRADAS"],[fmt(d.stats.acumulado),"PARADA ACUMULADA"],[fmt(Math.round(d.stats.promedio)),"PARADA PROMEDIO"]]}/><div className="panel"><h3>Órdenes de la máquina</h3>{d.ordenes.map(o=><div className="history" key={o.id}><b>{o.folio}</b> {badge(o.tipo)} {badge(o.estado)}<span>{o.descripcion}</span><small>Parada: {fmt(o.downtime_min||0)}</small></div>)}</div></section>
}
function Bars({rows,valueKey,labelKey="codigo",suffix=""}){
 const max=Math.max(1,...rows.map(x=>x[valueKey]||0));return <div>{rows.map((x,i)=><div className="barrow" key={i}><span>{x[labelKey]}</span><div><i style={{width:`${((x[valueKey]||0)/max)*100}%`}}/></div><b>{x[valueKey]}{suffix}</b></div>)}</div>
}
function Reports(){
 const [r,setR]=useState(null);useEffect(()=>{api("/reportes/resumen").then(setR)},[]);if(!r)return <p>Cargando...</p>;
 return <section><h2>Reportes e indicadores</h2><p className="muted">Información consolidada para la toma de decisiones.</p><Cards items={[[r.total,"ÓRDENES TOTALES"],[r.porcentajeCorrectivas+"%","PROPORCIÓN CORRECTIVA"],[fmt(r.downtime),"PARADA ACUMULADA"],[fmt(r.promedio),"PARADA PROMEDIO POR ORDEN"]]}/><div className="panel"><h3>Frecuencia de fallas por máquina</h3><Bars rows={r.fallas} valueKey="cantidad"/></div><div className="panel"><h3>Tiempo de parada por máquina (minutos)</h3><Bars rows={r.parada} valueKey="minutos"/></div><div className="panel"><h3>Causa raíz por categoría (6M)</h3><Bars rows={r.causas} valueKey="cantidad" labelKey="categoria"/></div><div className="panel"><h3>Estado actual del parque de máquinas</h3><table><thead><tr><th>ESTADO</th><th>CANTIDAD</th></tr></thead><tbody>{r.estados.map(x=><tr key={x.estado}><td>{x.estado}</td><td>{x.cantidad}</td></tr>)}</tbody></table></div></section>
}
function App(){
 const [user,setUser]=useState(()=>JSON.parse(localStorage.getItem("user")||"null")),[page,setPage]=useState("Panel de control");
 if(!user)return <Login onLogin={setUser}/>;
 const views={"Panel de control":<Dashboard/>,"Órdenes":<Orders/>,"Máquinas":<Machines/>,"Reportes":<Reports/>};
 return <Layout user={user} page={page} setPage={setPage} onLogout={()=>{localStorage.clear();setUser(null)}}>{views[page]}</Layout>
}
createRoot(document.getElementById("root")).render(<App/>);
