# SIGMAP — Sistema de Gestión de Mantenimiento

Prototipo académico basado en la documentación visual del proyecto SIGMAP.

## Tecnologías
- React + Vite
- Node.js + Express
- SQLite (better-sqlite3)
- JWT
- bcryptjs

## Ejecución

### Servidor
```bash
cd server
npm install
npm start
```

### Cliente
```bash
cd client
npm install
npm run dev
```

El frontend usa por defecto `http://localhost:5173` y la API `http://localhost:3001`.

## Usuario de demostración
- Correo: gerencia@sigmap.do
- Contraseña: 123456
