import Database from "better-sqlite3";
import bcrypt from "bcryptjs";

const db = new Database("sigmap.db");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS usuarios (
 id INTEGER PRIMARY KEY, nombre TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, rol TEXT NOT NULL CHECK(rol IN ('operador','tecnico','supervisor','gerencia'))
);
CREATE TABLE IF NOT EXISTS maquinas (
 id INTEGER PRIMARY KEY, codigo TEXT UNIQUE NOT NULL, nombre TEXT NOT NULL,
 tipo TEXT, area TEXT, estado TEXT NOT NULL DEFAULT 'operativa',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ordenes (
 id INTEGER PRIMARY KEY, folio TEXT UNIQUE NOT NULL, maquina_id INTEGER NOT NULL,
 tipo TEXT NOT NULL CHECK(tipo IN ('correctiva','preventiva')),
 prioridad TEXT NOT NULL, estado TEXT NOT NULL DEFAULT 'abierta',
 descripcion TEXT NOT NULL, reportado_por INTEGER, tecnico_id INTEGER,
 abierta_en TEXT DEFAULT CURRENT_TIMESTAMP, cerrada_en TEXT, downtime_min INTEGER DEFAULT 0,
 FOREIGN KEY(maquina_id) REFERENCES maquinas(id),
 FOREIGN KEY(reportado_por) REFERENCES usuarios(id),
 FOREIGN KEY(tecnico_id) REFERENCES usuarios(id)
);
CREATE TABLE IF NOT EXISTS causa_raiz (
 id INTEGER PRIMARY KEY, orden_id INTEGER UNIQUE NOT NULL,
 porque_1 TEXT NOT NULL, porque_2 TEXT, porque_3 TEXT, porque_4 TEXT, porque_5 TEXT,
 causa_identificada TEXT NOT NULL, categoria TEXT NOT NULL, accion_correctiva TEXT NOT NULL,
 responsable_id INTEGER, registrado_en TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(orden_id) REFERENCES ordenes(id)
);
CREATE TABLE IF NOT EXISTS notificaciones (
 id INTEGER PRIMARY KEY, usuario_id INTEGER, mensaje TEXT NOT NULL,
 leida INTEGER DEFAULT 0, creada_en TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const count = db.prepare("SELECT COUNT(*) c FROM usuarios").get().c;
if (!count) {
  const hash = bcrypt.hashSync("123456", 10);
  const u = db.prepare("INSERT INTO usuarios(nombre,email,password_hash,rol) VALUES(?,?,?,?)");
  u.run("Luis Peralta","gerencia@sigmap.do",hash,"gerencia");
  u.run("Ramón Cruz","tecnico@sigmap.do",hash,"tecnico");
  u.run("Ana Batista","operador@sigmap.do",hash,"operador");
  u.run("María Santos","supervisor@sigmap.do",hash,"supervisor");

  const m = db.prepare("INSERT INTO maquinas(codigo,nombre,tipo,area,estado) VALUES(?,?,?,?,?)");
  [
    ["INY-01","Inyectora Husky 160T","inyección","Nave A","operativa"],
    ["INY-02","Inyectora Engel 250T","inyección","Nave A","operativa"],
    ["SOP-01","Sopladora Aoki AL-250","soplado","Nave B","detenida"],
    ["SOP-02","Sopladora Nissei ASB","soplado","Nave B","en mantenimiento"],
    ["AUX-01","Compresor Atlas Copco GA-30","auxiliar","Cuarto de máquinas","operativa"],
    ["AUX-02","Chiller Trane CGAM-40","auxiliar","Cuarto de máquinas","operativa"]
  ].forEach(x=>m.run(...x));

  const o = db.prepare(`INSERT INTO ordenes(folio,maquina_id,tipo,prioridad,estado,descripcion,reportado_por,tecnico_id,downtime_min)
                        VALUES(?,?,?,?,?,?,?,?,?)`);
  o.run("OT-1001",2,"correctiva","alta","cerrada","Fuga de aceite hidráulico en la unidad de cierre.",3,2,270);
  o.run("OT-1002",1,"preventiva","media","cerrada","Mantenimiento preventivo programado.",3,2,180);
  o.run("OT-1003",4,"correctiva","critica","en proceso","Baja presión en sistema neumático.",3,2,0);
  o.run("OT-1004",1,"correctiva","media","asignada","Temperatura fuera de rango.",3,2,0);
  o.run("OT-1005",6,"preventiva","baja","abierta","Inspección general de enfriamiento.",3,null,0);
  o.run("OT-1006",2,"correctiva","alta","cerrada","Nueva fuga de aceite en la misma unidad de cierre.",3,2,330);
  o.run("OT-1007",1,"correctiva","alta","cerrada","Falla de sensor de presión.",3,2,0);

  db.prepare(`INSERT INTO causa_raiz
   (orden_id,porque_1,porque_2,porque_3,causa_identificada,categoria,accion_correctiva,responsable_id)
   VALUES(?,?,?,?,?,?,?,?)`).run(
    1,"La máquina presentó fuga de aceite.","El sello de la unidad de cierre estaba dañado.",
    "El sello trabajó a una presión superior a la normal.",
    "Ausencia de una rutina preventiva de calibración de la válvula reguladora de presión.",
    "Método","Incluir la calibración de la válvula reguladora en el plan preventivo trimestral y reemplazar el sello.",2
  );

  db.prepare("INSERT INTO notificaciones(usuario_id,mensaje) VALUES(?,?)").run(1,"Nueva orden OT-1007 de prioridad alta en INY-01.");
  db.prepare("INSERT INTO notificaciones(usuario_id,mensaje) VALUES(?,?)").run(1,"La máquina SOP-01 lleva más de 24 horas detenida.");
}
export default db;
