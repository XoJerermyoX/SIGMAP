import express from "express";
import cors from "cors";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import db from "./db.js";

const app = express();
const SECRET = process.env.JWT_SECRET || "sigmap-demo-secret";
app.use(cors());
app.use(express.json());

function auth(req,res,next){
  const token=(req.headers.authorization||"").replace("Bearer ","");
  try { req.user=jwt.verify(token,SECRET); next(); }
  catch { res.status(401).json({error:"Sesión inválida o expirada"}); }
}
function roles(...allowed){
  return (req,res,next)=> allowed.includes(req.user.rol) ? next() : res.status(403).json({error:"Acceso no autorizado"});
}

app.post("/api/auth/login",(req,res)=>{
  const u=db.prepare("SELECT * FROM usuarios WHERE email=?").get(req.body.email);
  if(!u || !bcrypt.compareSync(req.body.password||"",u.password_hash))
    return res.status(401).json({error:"Credenciales incorrectas"});
  const token=jwt.sign({id:u.id,nombre:u.nombre,rol:u.rol},SECRET,{expiresIn:"8h"});
  res.json({token,user:{id:u.id,nombre:u.nombre,rol:u.rol}});
});

app.get("/api/maquinas",auth,(req,res)=>res.json(db.prepare(`
 SELECT m.*, SUM(CASE WHEN o.estado!='cerrada' THEN 1 ELSE 0 END) ordenes_abiertas
 FROM maquinas m LEFT JOIN ordenes o ON o.maquina_id=m.id GROUP BY m.id ORDER BY m.codigo`).all()));

app.post("/api/maquinas",auth,roles("supervisor","gerencia"),(req,res)=>{
  const {codigo,nombre,tipo,area}=req.body;
  const info=db.prepare("INSERT INTO maquinas(codigo,nombre,tipo,area) VALUES(?,?,?,?)").run(codigo,nombre,tipo,area);
  res.status(201).json({id:info.lastInsertRowid});
});

app.get("/api/maquinas/:id/historial",auth,(req,res)=>{
  const maquina=db.prepare("SELECT * FROM maquinas WHERE id=?").get(req.params.id);
  const ordenes=db.prepare("SELECT * FROM ordenes WHERE maquina_id=? ORDER BY abierta_en DESC").all(req.params.id);
  const stats=db.prepare("SELECT COUNT(*) total, COALESCE(SUM(downtime_min),0) acumulado, COALESCE(AVG(NULLIF(downtime_min,0)),0) promedio FROM ordenes WHERE maquina_id=?").get(req.params.id);
  res.json({maquina,ordenes,stats});
});

app.get("/api/ordenes",auth,(req,res)=>{
  let sql=`SELECT o.*,m.codigo maquina,u.nombre tecnico,
    EXISTS(SELECT 1 FROM causa_raiz c WHERE c.orden_id=o.id) causa_raiz
    FROM ordenes o JOIN maquinas m ON m.id=o.maquina_id
    LEFT JOIN usuarios u ON u.id=o.tecnico_id WHERE 1=1`;
  const args=[];
  if(req.query.estado){sql+=" AND o.estado=?";args.push(req.query.estado)}
  if(req.query.tipo){sql+=" AND o.tipo=?";args.push(req.query.tipo)}
  sql+=" ORDER BY o.id DESC";
  res.json(db.prepare(sql).all(...args));
});

app.post("/api/ordenes",auth,(req,res)=>{
  const {maquina_id,tipo,prioridad,descripcion}=req.body;
  const next=db.prepare("SELECT COALESCE(MAX(id),0)+1001 n FROM ordenes").get().n;
  const folio=`OT-${next}`;
  const info=db.prepare(`INSERT INTO ordenes(folio,maquina_id,tipo,prioridad,descripcion,reportado_por)
    VALUES(?,?,?,?,?,?)`).run(folio,maquina_id,tipo,prioridad,descripcion,req.user.id);
  res.status(201).json({id:info.lastInsertRowid,folio});
});

app.get("/api/ordenes/:id",auth,(req,res)=>{
  const orden=db.prepare(`SELECT o.*,m.codigo maquina,m.nombre maquina_nombre,
    u.nombre tecnico,r.nombre reportado_nombre FROM ordenes o JOIN maquinas m ON m.id=o.maquina_id
    LEFT JOIN usuarios u ON u.id=o.tecnico_id LEFT JOIN usuarios r ON r.id=o.reportado_por WHERE o.id=?`).get(req.params.id);
  const causa=db.prepare("SELECT * FROM causa_raiz WHERE orden_id=?").get(req.params.id);
  res.json({orden,causa});
});

app.patch("/api/ordenes/:id/asignar",auth,roles("supervisor","gerencia"),(req,res)=>{
  const orden=db.prepare("SELECT * FROM ordenes WHERE id=?").get(req.params.id);
  db.prepare("UPDATE ordenes SET tecnico_id=?,estado='asignada' WHERE id=?").run(req.body.tecnico_id,req.params.id);
  db.prepare("UPDATE maquinas SET estado='en mantenimiento' WHERE id=?").run(orden.maquina_id);
  res.json({ok:true});
});

app.patch("/api/ordenes/:id/estado",auth,(req,res)=>{
  const orden=db.prepare("SELECT * FROM ordenes WHERE id=?").get(req.params.id);
  if(req.body.estado==="cerrada" && orden.tipo==="correctiva"){
    const causa=db.prepare("SELECT id FROM causa_raiz WHERE orden_id=?").get(req.params.id);
    if(!causa) return res.status(400).json({error:"Una orden correctiva no puede cerrarse sin análisis de causa raíz."});
  }
  if(req.body.estado==="cerrada"){
    db.prepare(`UPDATE ordenes SET estado='cerrada',cerrada_en=CURRENT_TIMESTAMP,
      downtime_min=CAST((julianday(CURRENT_TIMESTAMP)-julianday(abierta_en))*1440 AS INTEGER) WHERE id=?`).run(req.params.id);
    db.prepare("UPDATE maquinas SET estado='operativa' WHERE id=?").run(orden.maquina_id);
  } else db.prepare("UPDATE ordenes SET estado=? WHERE id=?").run(req.body.estado,req.params.id);
  res.json({ok:true});
});

app.post("/api/ordenes/:id/causa-raiz",auth,roles("tecnico","supervisor","gerencia"),(req,res)=>{
  const x=req.body;
  db.prepare(`INSERT INTO causa_raiz(orden_id,porque_1,porque_2,porque_3,porque_4,porque_5,causa_identificada,categoria,accion_correctiva,responsable_id)
    VALUES(?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(orden_id) DO UPDATE SET porque_1=excluded.porque_1,porque_2=excluded.porque_2,
    porque_3=excluded.porque_3,porque_4=excluded.porque_4,porque_5=excluded.porque_5,
    causa_identificada=excluded.causa_identificada,categoria=excluded.categoria,accion_correctiva=excluded.accion_correctiva`)
    .run(req.params.id,x.porque_1,x.porque_2||null,x.porque_3||null,x.porque_4||null,x.porque_5||null,x.causa_identificada,x.categoria,x.accion_correctiva,req.user.id);
  res.json({ok:true});
});

app.get("/api/reportes/resumen",auth,(req,res)=>{
  const total=db.prepare("SELECT COUNT(*) c FROM ordenes").get().c;
  const correctivas=db.prepare("SELECT COUNT(*) c FROM ordenes WHERE tipo='correctiva'").get().c;
  const downtime=db.prepare("SELECT COALESCE(SUM(downtime_min),0) n FROM ordenes").get().n;
  const promedio=db.prepare("SELECT COALESCE(AVG(NULLIF(downtime_min,0)),0) n FROM ordenes").get().n;
  const fallas=db.prepare(`SELECT m.codigo,COUNT(o.id) cantidad FROM maquinas m LEFT JOIN ordenes o ON o.maquina_id=m.id AND o.tipo='correctiva' GROUP BY m.id ORDER BY cantidad DESC`).all();
  const parada=db.prepare(`SELECT m.codigo,COALESCE(SUM(o.downtime_min),0) minutos FROM maquinas m LEFT JOIN ordenes o ON o.maquina_id=m.id GROUP BY m.id ORDER BY minutos DESC`).all();
  const causas=db.prepare("SELECT categoria,COUNT(*) cantidad FROM causa_raiz GROUP BY categoria ORDER BY cantidad DESC").all();
  const estados=db.prepare("SELECT estado,COUNT(*) cantidad FROM maquinas GROUP BY estado").all();
  res.json({total,porcentajeCorrectivas:total?Math.round(correctivas*100/total):0,downtime,promedio:Math.round(promedio),fallas,parada,causas,estados});
});

app.get("/api/notificaciones",auth,(req,res)=>res.json(db.prepare("SELECT * FROM notificaciones WHERE usuario_id=? ORDER BY id DESC").all(req.user.id)));
app.get("/api/tecnicos",auth,(req,res)=>res.json(db.prepare("SELECT id,nombre FROM usuarios WHERE rol='tecnico'").all()));

app.listen(3001,()=>console.log("SIGMAP API: http://localhost:3001"));
